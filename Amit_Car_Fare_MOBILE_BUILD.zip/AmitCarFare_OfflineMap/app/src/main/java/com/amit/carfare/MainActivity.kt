package com.amit.carfare

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { FareScreen() } }
    }
}

@Composable
fun FareScreen() {
    val context = LocalContext.current
    var pickup by remember { mutableStateOf("") }
    var drop by remember { mutableStateOf("") }
    var km by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("12") }
    var toll by remember { mutableStateOf("0") }
    var parking by remember { mutableStateOf("0") }
    var night by remember { mutableStateOf("0") }
    var waiting by remember { mutableStateOf("0") }
    var driver by remember { mutableStateOf("0") }
    var other by remember { mutableStateOf("0") }
    var advance by remember { mutableStateOf("0") }
    var roundTrip by remember { mutableStateOf(false) }
    var calculated by remember { mutableStateOf(false) }

    fun n(s: String) = s.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val distance = n(km) * if (roundTrip) 2 else 1
    val kmFare = distance * n(rate)
    val road = n(toll) + n(parking)
    val extras = n(night) + n(waiting) + n(driver) + n(other)
    val total = kmFare + road + extras
    val balance = (total - n(advance)).coerceAtLeast(0.0)
    val fmt = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply { maximumFractionDigits = 2 }

    @Composable
    fun field(label: String, value: String, onValue: (String) -> Unit, numeric: Boolean = false) {
        OutlinedTextField(value = value, onValueChange = onValue, label = { Text(label) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text))
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("🚕 Amit Car Fare", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("ऑफलाइन किराया और मैप")
        Button(onClick = { context.startActivity(Intent(context, OfflineMapActivity::class.java)) },
            modifier = Modifier.fillMaxWidth()) { Text("🗺️ UP • Delhi • Haryana • Rajasthan ऑफलाइन मैप") }
        field("Pickup Location", pickup, { pickup = it })
        field("Drop Location", drop, { drop = it })
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Checkbox(checked = roundTrip, onCheckedChange = { roundTrip = it; calculated = false })
            Text("Round Trip (आने-जाने का किराया)")
        }
        field("एक तरफ की दूरी (KM)", km, { km = it; calculated = false }, true)
        field("रेट (₹ प्रति KM)", rate, { rate = it; calculated = false }, true)
        HorizontalDivider()
        Text("अतिरिक्त खर्चे", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        field("Toll (₹)", toll, { toll = it; calculated = false }, true)
        field("Parking (₹)", parking, { parking = it; calculated = false }, true)
        field("Night Charge (₹)", night, { night = it; calculated = false }, true)
        field("Waiting (₹)", waiting, { waiting = it; calculated = false }, true)
        field("Driver Allowance (₹)", driver, { driver = it; calculated = false }, true)
        field("अन्य खर्च (₹)", other, { other = it; calculated = false }, true)
        field("Advance मिला (₹)", advance, { advance = it; calculated = false }, true)
        Button(onClick = { calculated = true }, modifier = Modifier.fillMaxWidth()) { Text("कुल किराया निकालें") }
        if (calculated) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("कस्टमर से कुल किराया", style = MaterialTheme.typography.titleMedium)
                    Text(fmt.format(total), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("${if (roundTrip) "Round Trip" else "One Way"} • ${"%.1f".format(distance)} KM")
                    HorizontalDivider()
                    resultLine("KM का किराया", fmt.format(kmFare))
                    resultLine("Toll + Parking", fmt.format(road))
                    resultLine("Night + Waiting + Driver + अन्य", fmt.format(extras))
                    resultLine("Advance के बाद बाकी", fmt.format(balance))
                    Button(onClick = {
                        val bill = """🚕 Amit Car Fare
$pickup → $drop
${if (roundTrip) "Round Trip" else "One Way"} | ${"%.1f".format(distance)} KM
KM Fare: ${fmt.format(kmFare)}
Toll: ${fmt.format(n(toll))}
Parking: ${fmt.format(n(parking))}
Night: ${fmt.format(n(night))}
Waiting: ${fmt.format(n(waiting))}
Driver: ${fmt.format(n(driver))}
Other: ${fmt.format(n(other))}
Total: ${fmt.format(total)}
Advance: ${fmt.format(n(advance))}
Balance Due: ${fmt.format(balance)}"""
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, bill) }
                        context.startActivity(Intent.createChooser(send, "बिल शेयर करें"))
                    }, modifier = Modifier.fillMaxWidth()) { Text("WhatsApp पर बिल शेयर करें") }
                }
            }
        }
        Text("किराया कैलकुलेशन ऑफलाइन चलेगा। मैप देखने के लिए संबंधित .map फाइल फोन में सेव करनी होगी।",
            style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun resultLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label); Text(value, fontWeight = FontWeight.SemiBold)
    }
}
