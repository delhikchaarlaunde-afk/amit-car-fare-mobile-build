AMIT CAR FARE - Offline Maps Android Project (v1.3)

Features:
- Offline fare calculator: One Way / Round Trip
- KM rate, Toll, Parking, Night, Waiting, Driver allowance, Other, Advance
- WhatsApp bill sharing
- Pickup/Drop भरने के बाद ऑनलाइन सड़क-दूरी और KM किराया अपने आप
- Offline vector map viewer using Mapsforge .map files
- Map file is copied into app-private storage and remains available offline

IMPORTANT MAP DATA NOTE:
The ZIP does NOT contain the actual UP/Delhi/Haryana/Rajasthan map data. The app needs
a Mapsforge-compatible .map file covering the North India region (or a suitable
regional map). You must obtain/download that map file separately while online,
then import it from the Offline Map screen. Once imported, map display works offline.
A normal .osm or .pbf file is not directly supported by this viewer.

Build:
1. Extract ZIP on a computer.
2. Open folder in Android Studio.
3. Wait for Gradle Sync (internet needed once to download libraries).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK path: app/build/outputs/apk/debug/app-debug.apk

Map library: Mapsforge 0.25.0. It is an open-source offline vector map renderer.
OpenStreetMap attribution should be retained in app distribution.

ROUTE DISTANCE NOTE (v1.3):
- Pickup और Drop की जगह भरने के बाद ऐप Android Geocoder से coordinates लेता है
  और OSRM public routing service से driving distance निकालता है।
- इसलिए ऑटो सड़क-दूरी के लिए इंटरनेट जरूरी है। OSRM public service की उपलब्धता
  की गारंटी नहीं है; असफल होने पर KM हाथ से भरें।
- Mapsforge .map फाइल केवल ऑफलाइन नक्शा दिखाती है; यह अपने आप offline turn-by-turn
  road routing नहीं देती।
- Toll और State Tax अभी मैन्युअल हैं। इस ZIP में सत्यापित toll/state-tax database
  शामिल नहीं है, इसलिए ऐप गलत अनुमान लगाकर रकम नहीं जोड़ेगा।
