Amit Car Fare Android App – Version 1.5

इस संस्करण में OTP Login UI हटाकर मोबाइल नंबर Login किया गया है। Driver Firebase Anonymous Authentication से sign in करता है। Admin नंबर +918920808755 के साथ PIN 1616 माँगा जाता है।

Build:
इस प्रोजेक्ट फ़ोल्डर में Gradle 8.9 और Java 17 से:
  gradle --no-daemon assembleDebug

APK path:
  app/build/outputs/apk/debug/app-debug.apk

पहले FIREBASE_SETUP_HI.txt पढ़ें। ध्यान दें: Admin PIN client-side है और सुरक्षित production authentication नहीं है। Admin cloud actions के लिए trusted backend/custom claims अभी configure करना बाकी है।
