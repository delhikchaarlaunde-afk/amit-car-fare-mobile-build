package com.amit.carfare

import android.content.Intent
import android.net.Uri
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import org.json.JSONObject

private const val ADMIN_PHONE = "+918920808755"
private const val ADMIN_PIN = "1616"
private const val PREFS = "amit_car_fare_session"
private val db get() = FirebaseFirestore.getInstance()

// Short in-app alert when a new open booking arrives while this screen is active.
private fun playBookingAlert() {
    try {
        val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
        tone.startTone(ToneGenerator.TONE_PROP_BEEP, 300)
        Handler(Looper.getMainLooper()).postDelayed({ tone.release() }, 500)
    } catch (_: Exception) { }
}

private data class AppSession(val uid: String, val phone: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        setContent {
            MaterialTheme {
                var session by remember {
                    mutableStateOf(FirebaseAuth.getInstance().currentUser?.let { u ->
                        prefs.getString("phone", null)?.let { AppSession(u.uid, it) }
                    })
                }
                if (session == null) {
                    PhoneLoginScreen { phone ->
                        val current = FirebaseAuth.getInstance().currentUser
                        if (current != null) {
                            prefs.edit().putString("phone", phone).apply()
                            session = AppSession(current.uid, phone)
                        }
                    }
                } else {
                    val active = session!!
                    BookingHome(active.uid, active.phone) {
                        prefs.edit().remove("phone").apply()
                        FirebaseAuth.getInstance().signOut()
                        session = null
                    }
                }
            }
        }
    }
}

@Composable
private fun PhoneLoginScreen(onLogin: (String) -> Unit) {
    val auth = remember { FirebaseAuth.getInstance() }
    var phone by remember { mutableStateOf("+91") }
    var pin by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("मोबाइल नंबर डालें। Admin के लिए PIN जरूरी है।") }
    val isAdminNumber = phone == ADMIN_PHONE

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement = Arrangement.Center) {
        Text("🚕 Amit Car Fare", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("मोबाइल Login", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it.filter { c -> c.isDigit() || c == '+' }.take(13) },
            label = { Text("मोबाइल नंबर (+91 सहित)") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true
        )
        if (isAdminNumber) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = pin,
                onValueChange = { pin = it.filter(Char::isDigit).take(4) },
                label = { Text("Admin PIN") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true
            )
        }
        Spacer(Modifier.height(12.dp))
        Button(
            enabled = !busy && phone.matches(Regex("^\\+[1-9]\\d{7,12}$")) && (!isAdminNumber || pin.length == 4),
            onClick = {
                if (isAdminNumber && pin != ADMIN_PIN) {
                    message = "Admin PIN गलत है।"
                } else {
                    busy = true
                    message = "Login हो रहा है…"
                    auth.signInAnonymously().addOnCompleteListener { task ->
                        busy = false
                        if (task.isSuccessful) onLogin(phone)
                        else message = task.exception?.localizedMessage ?: "Login नहीं हो सका। Firebase में Anonymous Authentication Enable करें।"
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "रुकें…" else "Login करें") }
        Spacer(Modifier.height(12.dp))
        Text(message)
        Text("Admin नंबर: $ADMIN_PHONE • Admin PIN से Login करें।", style = MaterialTheme.typography.bodySmall)
        Text("Driver Login में OTP नहीं लगेगा।", style = MaterialTheme.typography.bodySmall)
    }
}

private data class Booking(val id: String, val pickup: String, val drop: String, val km: Double, val fare: Double, val status: String, val createdBy: String, val assignedUid: String, val assignedPhone: String) {
    companion object { fun from(id: String, m: Map<String, Any>) = Booking(id, m["pickup"] as? String ?: "", m["drop"] as? String ?: "", (m["km"] as? Number)?.toDouble() ?: 0.0, (m["fare"] as? Number)?.toDouble() ?: 0.0, m["status"] as? String ?: "open", m["createdBy"] as? String ?: "", m["assignedDriverUid"] as? String ?: "", m["assignedDriverPhone"] as? String ?: "") }
}
private data class DriverRequest(val id: String, val bookingId: String, val driverUid: String, val phone: String, val status: String)

@Composable
private fun BookingHome(uid: String, phone: String, onLogout: () -> Unit) {
    val context = LocalContext.current
    val isAdmin = phone == ADMIN_PHONE
    var tab by remember { mutableStateOf(if (isAdmin) "Admin" else "Bookings") }
    var bookings by remember { mutableStateOf(listOf<Booking>()) }
    var requests by remember { mutableStateOf(listOf<DriverRequest>()) }
    var pickup by remember { mutableStateOf("") }; var drop by remember { mutableStateOf("") }; var km by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val refresh: () -> Unit = {
        // Anonymous-auth rules can only safely query documents explicitly allowed to the user.
        // Query open bookings for BOTH Admin and Drivers; an unfiltered Admin query is denied
        // by rules that only permit open/assigned booking reads.
        db.collection("bookings").whereEqualTo("status", "open").get()
            .addOnSuccessListener { snap ->
                val openBookings = snap.documents.map { Booking.from(it.id, it.data ?: emptyMap()) }
                if (isAdmin) {
                    bookings = openBookings
                } else {
                    db.collection("bookings").whereEqualTo("assignedDriverUid", uid).get()
                        .addOnSuccessListener { own ->
                            bookings = (openBookings + own.documents.map { Booking.from(it.id, it.data ?: emptyMap()) }).distinctBy { it.id }
                        }
                        .addOnFailureListener { err ->
                            bookings = openBookings
                            message = err.localizedMessage ?: "मेरे Orders लोड नहीं हुए"
                        }
                }
            }
            .addOnFailureListener { err -> message = err.localizedMessage ?: "बुकिंग लोड नहीं हुई" }
        if (isAdmin) db.collection("bookingRequests").whereEqualTo("status", "pending").get()
            .addOnSuccessListener { snap -> requests = snap.documents.map { DriverRequest(it.id, it.getString("bookingId") ?: "", it.getString("driverUid") ?: "", it.getString("phone") ?: "", it.getString("status") ?: "pending") } }
            .addOnFailureListener { err -> message = err.localizedMessage ?: "Driver requests लोड नहीं हुईं" }
    }
    LaunchedEffect(uid, isAdmin) { refresh() }
    // Keep the open-booking list live on every phone while the screen is open.
    DisposableEffect(uid, isAdmin) {
        // Ignore the first snapshot (existing bookings); beep only for newly published bookings.
        val knownOpenIds = mutableSetOf<String>()
        var firstSnapshot = true
        val liveBookings = db.collection("bookings").whereEqualTo("status", "open")
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    message = err.localizedMessage ?: "Live booking update नहीं मिला"
                } else if (snap != null) {
                    val openNow = snap.documents.map { Booking.from(it.id, it.data ?: emptyMap()) }
                    val currentIds = openNow.map { it.id }.toSet()
                    if (firstSnapshot) {
                        knownOpenIds.addAll(currentIds)
                        firstSnapshot = false
                    } else {
                        val hasNewBooking = currentIds.any { it !in knownOpenIds }
                        if (hasNewBooking) playBookingAlert()
                        knownOpenIds.addAll(currentIds)
                        knownOpenIds.retainAll(currentIds)
                    }
                    if (isAdmin) {
                        bookings = openNow
                    } else {
                        db.collection("bookings").whereEqualTo("assignedDriverUid", uid).get()
                            .addOnSuccessListener { own ->
                                bookings = (openNow + own.documents.map { Booking.from(it.id, it.data ?: emptyMap()) }).distinctBy { it.id }
                            }
                            .addOnFailureListener { bookings = openNow }
                    }
                }
            }
        onDispose { liveBookings.remove() }
    }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text("🚕 Amit Car Fare", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(if (isAdmin) "Admin • $phone" else "Driver • $phone")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { context.startActivity(Intent(context, OfflineMapActivity::class.java)) }) { Text("Offline Map") }
            if (isAdmin) { Button(onClick = { tab = "Admin" }) { Text("नई Booking") }; Button(onClick = { tab = "Requests" }) { Text("Driver Requests") } }
            Button(onClick = { tab = "Bookings"; refresh() }) { Text("Bookings / Orders") }
            TextButton(onClick = onLogout) { Text("Logout") }
        }
        HorizontalDivider(); Spacer(Modifier.height(8.dp))
        when (tab) {
            "Admin" -> {
                Text("नई Booking बनाएँ", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(pickup, { pickup = it }, label = { Text("Pickup") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(drop, { drop = it }, label = { Text("Drop") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(km, { km = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("दूरी KM") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                val fare = (km.toDoubleOrNull() ?: 0.0) * 15.0
                Text("किराया: ₹${String.format(Locale.US, "%.2f", fare)} (₹15/KM)", fontWeight = FontWeight.Bold)
                Button(enabled = !busy && pickup.isNotBlank() && drop.isNotBlank() && (km.toDoubleOrNull() ?: 0.0) > 0, onClick = {
                    busy = true
                    val data = hashMapOf<String, Any>("pickup" to pickup.trim(), "drop" to drop.trim(), "km" to (km.toDoubleOrNull() ?: 0.0), "fare" to fare, "status" to "open", "createdBy" to uid, "assignedDriverUid" to "", "assignedDriverPhone" to "", "createdAt" to System.currentTimeMillis())
                    db.collection("bookings").add(data).addOnSuccessListener {
                        busy = false
                        message = "Booking बन गई। Admin और Drivers की Booking List में दिखेगी।"
                        pickup = ""; drop = ""; km = ""
                        tab = "Bookings"
                        refresh()
                    }.addOnFailureListener { err -> busy = false; message = err.localizedMessage ?: "Booking नहीं बनी" }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "बना रहे हैं…" else "Booking Publish करें") }
            }
            "Requests" -> {
                Text("Drivers की Approval Requests", style = MaterialTheme.typography.titleLarge)
                Button(onClick = { refresh() }) { Text("Refresh") }
                LazyColumn(Modifier.weight(1f)) { items(requests) { r ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Column(Modifier.padding(12.dp)) {
                        Text("Booking: ${r.bookingId}"); Text("Driver: ${r.phone}")
                        Row { Button(onClick = {
                            busy = true
                            val bookingRef = db.collection("bookings").document(r.bookingId); val reqRef = db.collection("bookingRequests").document(r.id)
                            db.runTransaction { tx ->
                                val b = tx.get(bookingRef); val rq = tx.get(reqRef)
                                if (b.getString("status") != "open" || rq.getString("status") != "pending") throw Exception("यह Booking अब उपलब्ध नहीं है")
                                tx.update(bookingRef, mapOf("status" to "confirmed", "assignedDriverUid" to r.driverUid, "assignedDriverPhone" to r.phone, "confirmedAt" to System.currentTimeMillis()))
                                tx.update(reqRef, "status", "approved")
                            }.addOnSuccessListener { busy = false; message = "Driver request approve हो गई। Booking उसी driver को confirm है।"; refresh() }.addOnFailureListener { busy = false; message = it.localizedMessage ?: "Approval असफल" }
                        }) { Text("Approve & Confirm") }
                        TextButton(onClick = { db.collection("bookingRequests").document(r.id).update("status", "rejected").addOnSuccessListener { message = "Request reject की गई"; refresh() } }) { Text("Reject") } }
                    } }
                } }
            }
            else -> {
                Text(if (isAdmin) "सभी Bookings / Orders" else "Available Bookings और मेरे Orders", style = MaterialTheme.typography.titleLarge)
                Button(onClick = { refresh() }) { Text("Refresh") }
                LazyColumn(Modifier.weight(1f)) { items(bookings) { b ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("${b.pickup} → ${b.drop}", fontWeight = FontWeight.Bold)
                        Text("${b.km} KM • ₹${String.format(Locale.US, "%.2f", b.fare)} • ${b.status}")
                        if (b.assignedPhone.isNotBlank()) Text("Confirmed Driver: ${b.assignedPhone}")
                        if (!isAdmin && b.status == "open") Button(onClick = {
                            busy = true
                            val bookingRef = db.collection("bookings").document(b.id)
                            db.runTransaction { tx ->
                                val latest = tx.get(bookingRef)
                                if (latest.getString("status") != "open") {
                                    throw Exception("यह Booking किसी दूसरे Driver ने पहले ही Accept कर ली है")
                                }
                                tx.update(bookingRef, mapOf(
                                    "status" to "confirmed",
                                    "assignedDriverUid" to uid,
                                    "assignedDriverPhone" to phone,
                                    "acceptedAt" to System.currentTimeMillis()
                                ))
                            }.addOnSuccessListener {
                                busy = false
                                message = "Booking आपको मिल गई है। अब यह दूसरे Drivers को नहीं दिखेगी।"
                                refresh()
                            }.addOnFailureListener { err ->
                                busy = false
                                message = err.localizedMessage ?: "Booking Accept नहीं हुई। शायद कोई दूसरा Driver ले चुका है।"
                                refresh()
                            }
                        }, enabled = !busy) { Text("Booking Accept करें") }
                        if (isAdmin && b.status == "confirmed") TextButton(onClick = { db.collection("bookings").document(b.id).update("status", "completed").addOnSuccessListener { message = "Order Completed"; refresh() } }) { Text("Mark Completed") }
                        if (isAdmin && (b.status == "open" || b.status == "confirmed")) TextButton(onClick = { db.collection("bookings").document(b.id).update("status", "cancelled").addOnSuccessListener { message = "Booking Cancelled"; refresh() } }) { Text("Cancel Booking") }
                        OutlinedButton(onClick = { val u = "https://www.google.com/maps/dir/?api=1&origin=${Uri.encode(b.pickup)}&destination=${Uri.encode(b.drop)}&travelmode=driving"; context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }) { Text("Google Maps Route") }
                    } }
                } }
            }
        }
        if (message.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text(message, color = MaterialTheme.colorScheme.primary) }
        Text("Fare default ₹15/KM • Toll/State Tax अलग से सत्यापित करके जोड़ें।", style = MaterialTheme.typography.bodySmall)
    }
}
