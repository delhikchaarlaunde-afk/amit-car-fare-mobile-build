package com.amit.carfare

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { FareScreen() } }
    }
}

@Composable
fun FareScreen() {
    val context = LocalContext.current
    var pickup by remember { mutableStateOf("") }
    var drop by remember { mutableStateOf("") }
    var km by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("12") }
    var toll by remember { mutableStateOf("0") }
    var stateTax by remember { mutableStateOf("0") }
    var parking by remember { mutableStateOf("0") }
    var night by remember { mutableStateOf("0") }
    var waiting by remember { mutableStateOf("0") }
    var driver by remember { mutableStateOf("0") }
    var other by remember { mutableStateOf("0") }
    var advance by remember { mutableStateOf("0") }
    var vehicle by remember { mutableStateOf("Sedan / Dzire") }
    var roundTrip by remember { mutableStateOf(false) }
    var calculated by remember { mutableStateOf(false) }
    var locationMessage by remember { mutableStateOf("Pickup में GPS लोकेशन भरने के लिए बटन दबाएँ।") }

    fun n(s: String) = s.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val distance = n(km) * if (roundTrip) 2 else 1
    val kmFare = distance * n(rate)
    val road = n(toll) + n(stateTax) + n(parking)
    val extras = n(night) + n(waiting) + n(driver) + n(other)
    val total = kmFare + road + extras
    val balance = (total - n(advance)).coerceAtLeast(0.0)
    val fmt = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply { maximumFractionDigits = 2 }

    fun field(label: String, value: String, onValue: (String) -> Unit, numeric: Boolean = false) {
        OutlinedTextField(value = value, onValueChange = onValue, label = { Text(label) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text))
    }

    val locationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            fillCurrentLocation(context) { pickup = it; locationMessage = "वर्तमान लोकेशन Pickup में भर दी गई।" }
        } else locationMessage = "लोकेशन अनुमति नहीं मिली।"
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("🚕 Amit Car Fare", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("UP Registration • All India Tourist Permit")
        Button(onClick = { context.startActivity(Intent(context, OfflineMapActivity::class.java)) },
            modifier = Modifier.fillMaxWidth()) { Text("🗺️ ऑफलाइन मैप खोलें") }
        field("Pickup Location", pickup, { pickup = it; calculated = false })
        OutlinedButton(onClick = {
            val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (fine || coarse) fillCurrentLocation(context) { pickup = it; locationMessage = "वर्तमान लोकेशन Pickup में भर दी गई।" }
            else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }, modifier = Modifier.fillMaxWidth()) { Text("📍 मेरी वर्तमान लोकेशन Pickup में डालें") }
        Text(locationMessage, style = MaterialTheme.typography.bodySmall)
        field("Drop Location", drop, { drop = it; calculated = false })
        var vehicleExpanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = vehicleExpanded, onExpandedChange = { vehicleExpanded = it }) {
            OutlinedTextField(value = vehicle, onValueChange = {}, readOnly = true,
                label = { Text("Commercial Car Type") }, modifier = Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded = vehicleExpanded, onDismissRequest = { vehicleExpanded = false }) {
                listOf("Hatchback", "Sedan / Dzire", "Ertiga / XL6", "SUV", "Innova / Crysta").forEach {
                    DropdownMenuItem(text = { Text(it) }, onClick = { vehicle = it; vehicleExpanded = false })
                }
            }
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Checkbox(checked = roundTrip, onCheckedChange = { roundTrip = it; calculated = false })
            Text("Round Trip (आने-जाने का किराया)")
        }
        field("एक तरफ की दूरी (KM)", km, { km = it; calculated = false }, true)
        field("रेट (₹ प्रति KM)", rate, { rate = it; calculated = false }, true)
        HorizontalDivider()
        Text("टोल और टैक्स", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        field("Toll (₹) — पुष्टि की गई रकम", toll, { toll = it; calculated = false }, true)
        field("State Tax (₹) — लागू टैक्स की पुष्टि के बाद", stateTax, { stateTax = it; calculated = false }, true)
        Text("ध्यान दें: अभी ऐप टोल/State Tax की सरकारी दर अपने आप सत्यापित नहीं करता। गलत रकम जोड़ने से बचने के लिए रकम यहाँ भरें।",
            style = MaterialTheme.typography.bodySmall)
        field("Parking (₹)", parking, { parking = it; calculated = false }, true)
        field("Night Charge (₹)", night, { night = it; calculated = false }, true)
        field("Waiting (₹)", waiting, { waiting = it; calculated = false }, true)
        field("Driver Allowance (₹)", driver, { driver = it; calculated = false }, true)
        field("अन्य खर्च (₹)", other, { other = it; calculated = false }, true)
        field("Advance मिला (₹)", advance, { advance = it; calculated = false }, true)
        Button(onClick = { calculated = true }, modifier = Modifier.fillMaxWidth()) { Text("कुल किराया निकालें") }
        if (calculated) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("कस्टमर से कुल किराया", style = MaterialTheme.typography.titleMedium)
                    Text(fmt.format(total), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("${if (roundTrip) "Round Trip" else "One Way"} • ${"%.1f".format(distance)} KM • $vehicle")
                    HorizontalDivider()
                    resultLine("KM का किराया", fmt.format(kmFare))
                    resultLine("Toll", fmt.format(n(toll)))
                    resultLine("State Tax", fmt.format(n(stateTax)))
                    resultLine("Parking", fmt.format(n(parking)))
                    resultLine("अन्य खर्च", fmt.format(extras))
                    resultLine("Advance के बाद बाकी", fmt.format(balance))
                    Button(onClick = {
                        val bill = """🚕 Amit Car Fare
Vehicle: $vehicle
$pickup → $drop
${if (roundTrip) "Round Trip" else "One Way"} | ${"%.1f".format(distance)} KM
KM Fare: ${fmt.format(kmFare)}
Toll: ${fmt.format(n(toll))}
State Tax: ${fmt.format(n(stateTax))}
Parking: ${fmt.format(n(parking))}
Night: ${fmt.format(n(night))}
Waiting: ${fmt.format(n(waiting))}
Driver: ${fmt.format(n(driver))}
Other: ${fmt.format(n(other))}
Total: ${fmt.format(total)}
Advance: ${fmt.format(n(advance))}
Balance Due: ${fmt.format(balance)}"""
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, bill) }
                        context.startActivity(Intent.createChooser(send, "बिल शेयर करें"))
                    }, modifier = Modifier.fillMaxWidth()) { Text("WhatsApp पर बिल शेयर करें") }
                }
            }
        }
        Text("ऑफलाइन किराया कैलकुलेशन चलता है। GPS लोकेशन के लिए डिवाइस लोकेशन चालू रखें। रूट दूरी अभी मैन्युअल भरनी होगी।",
            style = MaterialTheme.typography.bodySmall)
    }
}

private fun fillCurrentLocation(context: android.content.Context, onResult: (String) -> Unit) {
    try {
        val lm = context.getSystemService(ComponentActivity.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        val loc: Location? = providers.mapNotNull { provider ->
            try { lm.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
        }.maxByOrNull { it.time }
        if (loc == null) {
            onResult("लोकेशन नहीं मिली। GPS चालू करके बाहर खुले स्थान पर दोबारा कोशिश करें।")
            return
        }
        val address = try {
            @Suppress("DEPRECATION")
            Geocoder(context, Locale("en", "IN")).getFromLocation(loc.latitude, loc.longitude, 1)
                ?.firstOrNull()?.getAddressLine(0)
        } catch (_: Exception) { null }
        onResult(address ?: "GPS: ${loc.latitude}, ${loc.longitude}")
    } catch (_: Exception) {
        onResult("लोकेशन प्राप्त नहीं हो सकी।")
    }
}

@Composable
fun resultLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label); Text(value, fontWeight = FontWeight.SemiBold)
    }
}
