Amit Car Fare Android App

इस अपडेट में OTP स्क्रीन हटाकर मोबाइल नंबर Login जोड़ा गया है। Admin नंबर +918920808755 पर PIN 1616 माँगा जाएगा। अन्य नंबर Driver स्क्रीन खोलेंगे। Firebase Anonymous Authentication का उपयोग किया गया है।

महत्वपूर्ण सुरक्षा/सेटअप:
1. Firebase Console > Authentication > Sign-in method में Anonymous provider Enable करें।
2. बिना OTP के मोबाइल नंबर सत्यापित नहीं होता। इसलिए Driver का दर्ज किया नंबर केवल label है, verified identity नहीं।
3. Admin PIN ऐप के अंदर local check है; APK से PIN निकाला जा सकता है। इसे production-grade सुरक्षा न मानें।
4. मौजूदा firestore.rules में Admin के लिए verified Firebase phone token जरूरी है। Anonymous login उस token को नहीं देता, इसलिए Admin की cloud booking create/approve/update क्रियाएँ तब तक Firestore से reject होंगी जब तक सुरक्षित server-side Admin authentication (Firebase custom token/claims या Cloud Function) configure न हो। Rules को सभी signed-in users के लिए खुला न करें।

Build:
GitHub Actions workflow .github/workflows/build-apk.yml Java 17 और Gradle 8.9 के साथ debug APK बनाता है। इस environment में Gradle उपलब्ध नहीं था, इसलिए APK build/test नहीं किया गया है।
