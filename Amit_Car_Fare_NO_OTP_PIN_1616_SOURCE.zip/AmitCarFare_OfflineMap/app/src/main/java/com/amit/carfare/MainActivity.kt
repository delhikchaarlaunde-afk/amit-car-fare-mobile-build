package com.amit.carfare

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseException
import com.google.firebase.auth.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit
import org.json.JSONObject

private const val ADMIN_PHONE = "+918920808755"
private const val ADMIN_PIN = "1616"
private const val PREFS = "amit_car_fare_login"
private const val PREF_PHONE = "phone"
private val db get() = FirebaseFirestore.getInstance()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
                var user by remember { mutableStateOf(FirebaseAuth.getInstance().currentUser) }
                var savedPhone by remember { mutableStateOf(prefs.getString(PREF_PHONE, "") ?: "") }
                if (user == null || savedPhone.isBlank()) {
                    PhoneLoginScreen { phone ->
                        savedPhone = phone
                        user = FirebaseAuth.getInstance().currentUser
                    }
                } else {
                    BookingHome(user!!.uid, savedPhone) {
                        prefs.edit().remove(PREF_PHONE).apply()
                        FirebaseAuth.getInstance().signOut()
                        user = null
                        savedPhone = ""
                    }
                }
            }
        }
    }
}

@Composable
private fun PhoneLoginScreen(onLogin: (String) -> Unit) {
    val context = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    val prefs = remember { context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE) }
    var phone by remember { mutableStateOf("+91") }
    var pin by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("मोबाइल नंबर डालें। Admin के लिए PIN भी भरें।") }
    val isAdminNumber = phone == ADMIN_PHONE
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement = Arrangement.Center) {
        Text("🚕 Amit Car Fare", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp)); Text("मोबाइल नंबर से Login", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() || c == '+' }.take(13) }, label = { Text("मोबाइल नंबर (+91 सहित)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true)
        if (isAdminNumber) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(4) }, label = { Text("Admin PIN") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
        }
        Spacer(Modifier.height(12.dp))
        Button(enabled = !busy && phone.matches(Regex("^\\+[1-9]\\d{7,12}$")) && (!isAdminNumber || pin.length == 4), onClick = {
            if (isAdminNumber && pin != ADMIN_PIN) {
                message = "Admin PIN गलत है।"
            } else {
                busy = true
                message = "Login हो रहा है…"
                val finish: () -> Unit = {
                    prefs.edit().putString(PREF_PHONE, phone).apply()
                    busy = false
                    onLogin(phone)
                }
                if (auth.currentUser != null) finish()
                else auth.signInAnonymously().addOnSuccessListener { finish() }
                    .addOnFailureListener { busy = false; message = "Login नहीं हुआ: ${it.localizedMessage ?: "Firebase Anonymous Authentication Enable करें"}" }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "रुकें…" else "Login करें") }
        Spacer(Modifier.height(12.dp)); Text(message)
        Text("Admin नंबर: केवल इस नंबर और PIN से Admin स्क्रीन खुलेगी।", style = MaterialTheme.typography.bodySmall)
        Text("नोट: बिना OTP मोबाइल नंबर सत्यापित नहीं होता। सुरक्षित Admin अधिकार के लिए Firebase में server-side verification और Firestore Rules अपडेट जरूरी हैं।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
    }
}

private data class Booking(val id: String, val pickup: String, val drop: String, val km: Double, val fare: Double, val status: String, val createdBy: String, val assignedUid: String, val assignedPhone: String) {
    companion object { fun from(id: String, m: Map<String, Any>) = Booking(id, m["pickup"] as? String ?: "", m["drop"] as? String ?: "", (m["km"] as? Number)?.toDouble() ?: 0.0, (m["fare"] as? Number)?.toDouble() ?: 0.0, m["status"] as? String ?: "open", m["createdBy"] as? String ?: "", m["assignedDriverUid"] as? String ?: "", m["assignedDriverPhone"] as? String ?: "") }
}
private data class DriverRequest(val id: String, val bookingId: String, val driverUid: String, val phone: String, val status: String)

@Composable
private fun BookingHome(uid: String, phone: String, onLogout: () -> Unit) {
    val context = LocalContext.current
    val isAdmin = phone == ADMIN_PHONE
    var tab by remember { mutableStateOf(if (isAdmin) "Admin" else "Bookings") }
    var bookings by remember { mutableStateOf(listOf<Booking>()) }
    var requests by remember { mutableStateOf(listOf<DriverRequest>()) }
    var pickup by remember { mutableStateOf("") }; var drop by remember { mutableStateOf("") }; var km by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val refresh: () -> Unit = {
        val q = if (isAdmin) db.collection("bookings") else db.collection("bookings").whereEqualTo("status", "open")
        q.get().addOnSuccessListener { snap ->
            val first = snap.documents.map { Booking.from(it.id, it.data ?: emptyMap()) }
            if (isAdmin) bookings = first else db.collection("bookings").whereEqualTo("assignedDriverUid", uid).get().addOnSuccessListener { own -> bookings = (first + own.documents.map { Booking.from(it.id, it.data ?: emptyMap()) }).distinctBy { it.id } }
        }.addOnFailureListener { message = it.localizedMessage ?: "बुकिंग लोड नहीं हुई" }
        if (isAdmin) db.collection("bookingRequests").whereEqualTo("status", "pending").get().addOnSuccessListener { snap -> requests = snap.documents.map { DriverRequest(it.id, it.getString("bookingId") ?: "", it.getString("driverUid") ?: "", it.getString("phone") ?: "", it.getString("status") ?: "pending") } }
    }
    LaunchedEffect(uid, isAdmin) { refresh() }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text("🚕 Amit Car Fare", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(if (isAdmin) "Admin • $phone" else "Driver • $phone")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { context.startActivity(Intent(context, OfflineMapActivity::class.java)) }) { Text("Offline Map") }
            if (isAdmin) { Button(onClick = { tab = "Admin" }) { Text("नई Booking") }; Button(onClick = { tab = "Requests" }) { Text("Driver Requests") } }
            Button(onClick = { tab = "Bookings"; refresh() }) { Text("Bookings / Orders") }
            TextButton(onClick = onLogout) { Text("Logout") }
        }
        HorizontalDivider(); Spacer(Modifier.height(8.dp))
        when (tab) {
            "Admin" -> {
                Text("नई Booking बनाएँ", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(pickup, { pickup = it }, label = { Text("Pickup") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(drop, { drop = it }, label = { Text("Drop") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(km, { km = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("दूरी KM") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                val fare = (km.toDoubleOrNull() ?: 0.0) * 15.0
                Text("किराया: ₹${String.format(Locale.US, "%.2f", fare)} (₹15/KM)", fontWeight = FontWeight.Bold)
                Button(enabled = !busy && pickup.isNotBlank() && drop.isNotBlank() && (km.toDoubleOrNull() ?: 0.0) > 0, onClick = {
                    busy = true
                    val data = hashMapOf<String, Any>("pickup" to pickup.trim(), "drop" to drop.trim(), "km" to (km.toDoubleOrNull() ?: 0.0), "fare" to fare, "status" to "open", "createdBy" to uid, "assignedDriverUid" to "", "assignedDriverPhone" to "", "createdAt" to System.currentTimeMillis())
                    db.collection("bookings").add(data).addOnSuccessListener { busy = false; message = "Booking बन गई। Drivers को दिखेगी।"; pickup = ""; drop = ""; km = ""; refresh() }.addOnFailureListener { busy = false; message = it.localizedMessage ?: "Booking नहीं बनी" }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "बना रहे हैं…" else "Booking Publish करें") }
            }
            "Requests" -> {
                Text("Drivers की Approval Requests", style = MaterialTheme.typography.titleLarge)
                Button(onClick = { refresh() }) { Text("Refresh") }
                LazyColumn(Modifier.weight(1f)) { items(requests) { r ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Column(Modifier.padding(12.dp)) {
                        Text("Booking: ${r.bookingId}"); Text("Driver: ${r.phone}")
                        Row { Button(onClick = {
                            busy = true
                            val bookingRef = db.collection("bookings").document(r.bookingId); val reqRef = db.collection("bookingRequests").document(r.id)
                            db.runTransaction { tx ->
                                val b = tx.get(bookingRef); val rq = tx.get(reqRef)
                                if (b.getString("status") != "open" || rq.getString("status") != "pending") throw Exception("यह Booking अब उपलब्ध नहीं है")
                                tx.update(bookingRef, mapOf("status" to "confirmed", "assignedDriverUid" to r.driverUid, "assignedDriverPhone" to r.phone, "confirmedAt" to System.currentTimeMillis()))
                                tx.update(reqRef, "status", "approved")
                            }.addOnSuccessListener { busy = false; message = "Driver request approve हो गई। Booking उसी driver को confirm है।"; refresh() }.addOnFailureListener { busy = false; message = it.localizedMessage ?: "Approval असफल" }
                        }) { Text("Approve & Confirm") }
                        TextButton(onClick = { db.collection("bookingRequests").document(r.id).update("status", "rejected").addOnSuccessListener { message = "Request reject की गई"; refresh() } }) { Text("Reject") } }
                    } }
                } }
            }
            else -> {
                Text(if (isAdmin) "सभी Bookings / Orders" else "Available Bookings और मेरे Orders", style = MaterialTheme.typography.titleLarge)
                Button(onClick = { refresh() }) { Text("Refresh") }
                LazyColumn(Modifier.weight(1f)) { items(bookings) { b ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("${b.pickup} → ${b.drop}", fontWeight = FontWeight.Bold)
                        Text("${b.km} KM • ₹${String.format(Locale.US, "%.2f", b.fare)} • ${b.status}")
                        if (b.assignedPhone.isNotBlank()) Text("Confirmed Driver: ${b.assignedPhone}")
                        if (!isAdmin && b.status == "open") Button(onClick = {
                            val data = hashMapOf("bookingId" to b.id, "driverUid" to uid, "phone" to phone, "status" to "pending", "createdAt" to System.currentTimeMillis())
                            val requestId = "${b.id}_${uid}"
                            db.collection("bookingRequests").document(requestId).get().addOnSuccessListener { existing ->
                                if (existing.exists()) message = "आपकी request पहले से भेजी गई है"
                                else db.collection("bookingRequests").document(requestId).set(data).addOnSuccessListener { message = "Request Admin को भेज दी गई। Admin approval के बाद ही Booking confirm होगी।"; refresh() }.addOnFailureListener { message = it.localizedMessage ?: "Request नहीं भेजी गई" }
                            }.addOnFailureListener { message = it.localizedMessage ?: "Request जाँच नहीं हो सकी" }
                        }) { Text("Booking के लिए Request भेजें") }
                        if (isAdmin && b.status == "confirmed") TextButton(onClick = { db.collection("bookings").document(b.id).update("status", "completed").addOnSuccessListener { message = "Order Completed"; refresh() } }) { Text("Mark Completed") }
                        if (isAdmin && (b.status == "open" || b.status == "confirmed")) TextButton(onClick = { db.collection("bookings").document(b.id).update("status", "cancelled").addOnSuccessListener { message = "Booking Cancelled"; refresh() } }) { Text("Cancel Booking") }
                        OutlinedButton(onClick = { val u = "https://www.google.com/maps/dir/?api=1&origin=${Uri.encode(b.pickup)}&destination=${Uri.encode(b.drop)}&travelmode=driving"; context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }) { Text("Google Maps Route") }
                    } }
                } }
            }
        }
        if (message.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text(message, color = MaterialTheme.colorScheme.primary) }
        Text("Fare default ₹15/KM • Toll/State Tax अलग से सत्यापित करके जोड़ें।", style = MaterialTheme.typography.bodySmall)
    }
}
