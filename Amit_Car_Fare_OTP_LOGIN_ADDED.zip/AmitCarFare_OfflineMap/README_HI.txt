Amit Car Fare Android App

मुख्य फीचर: OTP login, Admin/Driver roles, Booking request + Admin approval, Orders status, ₹15/KM fare, Google Maps directions, optional offline Mapsforge map file.

Build: GitHub Actions workflow repo root .github/workflows/build-apk.yml से चलाएँ। Workflow ZIP extract करके AmitCarFare_OfflineMap/app/build/outputs/apk/debug/app-debug.apk बनाता है।

पहले FIREBASE_SETUP_HI.txt पढ़कर Firebase Phone Auth, Firestore Rules और signing fingerprints सेट करें। Build सफल होना और Firebase runtime setup पूरा होना अलग-अलग बातें हैं।
