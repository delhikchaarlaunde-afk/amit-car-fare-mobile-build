AMIT CAR FARE - VERSION 1.4

क्या काम करता है:
- Pickup और Drop के पते से ऑनलाइन सड़क दूरी खोजता है।
- OpenStreetMap Nominatim से address geocoding और OSRM public router से driving distance लेता है।
- दूरी मिलने पर KM field अपने आप भरता है; ₹/KM, Round Trip, extras और advance से कुल किराया निकलता है।
- Google Maps navigation intent से Google Maps/ब्राउज़र में driving route खोला जा सकता है।
- फोन में पहले से मौजूद Mapsforge .map फाइल चुनकर offline map देखा जा सकता है।
- App launcher icon में यूज़र द्वारा दी गई फोटो-आधारित डिज़ाइन शामिल है।

महत्वपूर्ण सीमाएँ:
- ऑनलाइन दूरी के लिए इंटरनेट चाहिए। Nominatim/OSRM सार्वजनिक सेवाएँ हैं; उनकी rate limits हैं और uptime की गारंटी नहीं। बहुत बार लगातार खोज न करें।
- Offline .map फाइल ZIP में शामिल नहीं है। उपयोगकर्ता को अपने क्षेत्र की compatible Mapsforge .map फाइल अलग से डाउनलोड करके ऐप में चुननी होगी।
- Offline सड़क routing इस build में शामिल नहीं है; offline map केवल map display करता है।
- Toll amount और State Tax अभी automatic नहीं हैं। इन्हें सही निकालने के लिए route-wise toll database/API तथा registration state, permit, seating capacity, vehicle class और यात्रा की तारीख के अनुसार verified official tax rules चाहिए। अभी Toll और State Tax fields manual हैं ताकि गलत रकम न जुड़े।
- यह build किसी सरकारी टैक्स/FASTag रकम की गारंटी नहीं देता।

Build:
Android Studio में यह project folder खोलें और Build > Build APK(s) चलाएँ।
