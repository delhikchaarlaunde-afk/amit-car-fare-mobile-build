package com.amit.carfare

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var loggedIn by remember { mutableStateOf(com.google.firebase.auth.FirebaseAuth.getInstance().currentUser != null) }
                if (loggedIn) FareScreen(onLogout = {
                    com.google.firebase.auth.FirebaseAuth.getInstance().signOut()
                    loggedIn = false
                }) else PhoneLoginScreen(onLogin = { loggedIn = true })
            }
        }
    }
}

@Composable
fun PhoneLoginScreen(onLogin: () -> Unit) {
    val context = LocalContext.current
    val auth = remember { com.google.firebase.auth.FirebaseAuth.getInstance() }
    var phone by remember { mutableStateOf("+91") }
    var otp by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("मोबाइल नंबर डालें। OTP SMS से आएगा।") }
    val activity = context as? android.app.Activity

    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.Center) {
        Text("🚕 Amit Car Fare", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("ड्राइवर मोबाइल OTP लॉगिन", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = phone, onValueChange = { phone = it.filter { ch -> ch.isDigit() || ch == '+' }.take(13) },
            label = { Text("मोबाइल नंबर (+91 सहित)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
        )
        if (verificationId == null) {
            Button(
                enabled = !busy && phone.matches(Regex("^\\+[1-9]\\d{7,12}$")) && activity != null,
                onClick = {
                    busy = true
                    message = "OTP भेजा जा रहा है…"
                    val callbacks = object : com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                        override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                            auth.signInWithCredential(credential).addOnCompleteListener { task ->
                                busy = false
                                if (task.isSuccessful) onLogin() else message = task.exception?.localizedMessage ?: "लॉगिन नहीं हुआ।"
                            }
                        }
                        override fun onVerificationFailed(e: com.google.firebase.FirebaseException) {
                            busy = false
                            message = e.localizedMessage ?: "OTP भेजने में समस्या। Firebase सेटिंग जाँचें।"
                        }
                        override fun onCodeSent(id: String, token: com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken) {
                            verificationId = id
                            busy = false
                            message = "OTP भेज दिया गया। SMS में आया 6 अंकों का OTP भरें।"
                        }
                    }
                    val options = com.google.firebase.auth.PhoneAuthOptions.newBuilder(auth)
                        .setPhoneNumber(phone).setTimeout(60L, java.util.concurrent.TimeUnit.SECONDS)
                        .setActivity(activity!!).setCallbacks(callbacks).build()
                    com.google.firebase.auth.PhoneAuthProvider.verifyPhoneNumber(options)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "कृपया रुकें…" else "OTP भेजें") }
        } else {
            OutlinedTextField(
                value = otp, onValueChange = { otp = it.filter(Char::isDigit).take(6) },
                label = { Text("6 अंकों का OTP") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Button(enabled = !busy && otp.length == 6, onClick = {
                busy = true
                val credential = com.google.firebase.auth.PhoneAuthProvider.getCredential(verificationId!!, otp)
                auth.signInWithCredential(credential).addOnCompleteListener { task ->
                    busy = false
                    if (task.isSuccessful) onLogin()
                    else message = task.exception?.localizedMessage ?: "गलत OTP या लॉगिन विफल।"
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "जाँच हो रही है…" else "OTP Verify करके Login करें") }
        }
        Spacer(Modifier.height(12.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun FareScreen(onLogout: () -> Unit = {}) {
    val context = LocalContext.current
    var pickup by remember { mutableStateOf("") }
    var drop by remember { mutableStateOf("") }
    var km by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("12") }
    var toll by remember { mutableStateOf("0") }
    var stateTax by remember { mutableStateOf("0") }
    var parking by remember { mutableStateOf("0") }
    var night by remember { mutableStateOf("0") }
    var waiting by remember { mutableStateOf("0") }
    var driver by remember { mutableStateOf("0") }
    var other by remember { mutableStateOf("0") }
    var advance by remember { mutableStateOf("0") }
    var vehicle by remember { mutableStateOf("Sedan / Dzire") }
    var roundTrip by remember { mutableStateOf(false) }
    var calculated by remember { mutableStateOf(false) }
    var locationMessage by remember { mutableStateOf("Pickup और Drop भरकर सड़क की दूरी निकालें।") }
    var routeLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // After the user finishes entering both place names, look up the driving route automatically.
    LaunchedEffect(pickup, drop) {
        if (pickup.isNotBlank() && drop.isNotBlank()) {
            delay(1000)
            routeLoading = true
            locationMessage = "Pickup और Drop का सड़क रूट खोजा जा रहा है…"
            val result = withContext(Dispatchers.IO) { getDrivingDistanceKm(context, pickup, drop) }
            routeLoading = false
            if (result.first != null) {
                km = String.format(Locale.US, "%.1f", result.first)
                calculated = false
                locationMessage = "ऑनलाइन सड़क दूरी: ${String.format(Locale.US, "%.1f", result.first)} KM"
            } else {
                locationMessage = result.second ?: "रूट नहीं मिला। इंटरनेट या लोकेशन नाम जाँचें।"
            }
        }
    }

    fun n(s: String) = s.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val distance = n(km) * if (roundTrip) 2 else 1
    val kmFare = distance * n(rate)
    val road = n(toll) + n(stateTax) + n(parking)
    val extras = n(night) + n(waiting) + n(driver) + n(other)
    val total = kmFare + road + extras
    val balance = (total - n(advance)).coerceAtLeast(0.0)
    val fmt = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply { maximumFractionDigits = 2 }

    fun field(label: String, value: String, onValue: (String) -> Unit, numeric: Boolean = false) {
        OutlinedTextField(value = value, onValueChange = onValue, label = { Text(label) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text))
    }

    val locationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            fillCurrentLocation(context) { pickup = it; locationMessage = "वर्तमान लोकेशन Pickup में भर दी गई।" }
        } else locationMessage = "लोकेशन अनुमति नहीं मिली।"
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("🚕 Amit Car Fare", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("UP Registration • All India Tourist Permit")
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("Logout") }
        Button(onClick = { context.startActivity(Intent(context, OfflineMapActivity::class.java)) },
            modifier = Modifier.fillMaxWidth()) { Text("🗺️ ऑफलाइन मैप खोलें") }
        field("Pickup Location", pickup, { pickup = it; calculated = false })
        OutlinedButton(onClick = {
            val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (fine || coarse) fillCurrentLocation(context) { pickup = it; locationMessage = "वर्तमान लोकेशन Pickup में भर दी गई।" }
            else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }, modifier = Modifier.fillMaxWidth()) { Text("📍 मेरी वर्तमान लोकेशन Pickup में डालें") }
        Text(locationMessage, style = MaterialTheme.typography.bodySmall)
        field("Drop Location", drop, { drop = it; calculated = false })
        OutlinedButton(
            onClick = {
                if (pickup.isBlank() || drop.isBlank()) {
                    locationMessage = "Google Maps खोलने से पहले Pickup और Drop दोनों भरें।"
                } else {
                    val mapsUrl = "https://www.google.com/maps/dir/?api=1" +
                        "&origin=${Uri.encode(pickup)}" +
                        "&destination=${Uri.encode(drop)}" +
                        "&travelmode=driving"
                    val mapsIntent = Intent(Intent.ACTION_VIEW, Uri.parse(mapsUrl))
                    try {
                        context.startActivity(mapsIntent)
                    } catch (_: Exception) {
                        locationMessage = "Google Maps या ब्राउज़र उपलब्ध नहीं है।"
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("🌐 Google Maps में रूट देखें / नेविगेशन") }
        Button(onClick = {
            if (pickup.isBlank() || drop.isBlank()) {
                locationMessage = "पहले Pickup और Drop दोनों भरें।"
            } else {
                routeLoading = true
                locationMessage = "रूट और सड़क की दूरी खोजी जा रही है…"
                scope.launch {
                    val result = withContext(Dispatchers.IO) { getDrivingDistanceKm(context, pickup, drop) }
                    routeLoading = false
                    if (result.first != null) {
                        km = String.format(Locale.US, "%.1f", result.first)
                        calculated = false
                        locationMessage = "सड़क की दूरी मिल गई: ${String.format(Locale.US, "%.1f", result.first)} KM (ऑनलाइन रूट)।"
                    } else {
                        locationMessage = result.second ?: "रूट नहीं मिला। इंटरनेट या लोकेशन नाम जाँचें।"
                    }
                }
            }
        }, enabled = !routeLoading, modifier = Modifier.fillMaxWidth()) {
            Text(if (routeLoading) "रूट खोज रहे हैं…" else "🛣️ सड़क की दूरी अपने आप निकालें")
        }
        Text(locationMessage, style = MaterialTheme.typography.bodySmall)
        var vehicleExpanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = vehicleExpanded, onExpandedChange = { vehicleExpanded = it }) {
            OutlinedTextField(value = vehicle, onValueChange = {}, readOnly = true,
                label = { Text("Commercial Car Type") }, modifier = Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded = vehicleExpanded, onDismissRequest = { vehicleExpanded = false }) {
                listOf("Hatchback", "Sedan / Dzire", "Ertiga / XL6", "SUV", "Innova / Crysta").forEach {
                    DropdownMenuItem(text = { Text(it) }, onClick = { vehicle = it; vehicleExpanded = false })
                }
            }
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Checkbox(checked = roundTrip, onCheckedChange = { roundTrip = it; calculated = false })
            Text("Round Trip (आने-जाने का किराया)")
        }
        field("एक तरफ की दूरी (KM)", km, { km = it; calculated = false }, true)
        field("रेट (₹ प्रति KM)", rate, { rate = it; calculated = false }, true)
        HorizontalDivider()
        Text("टोल और टैक्स", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        field("Toll (₹) — पुष्टि की गई रकम", toll, { toll = it; calculated = false }, true)
        field("State Tax (₹) — लागू टैक्स की पुष्टि के बाद", stateTax, { stateTax = it; calculated = false }, true)
        Text("ध्यान दें: अभी ऐप टोल/State Tax की सरकारी दर अपने आप सत्यापित नहीं करता। गलत रकम जोड़ने से बचने के लिए रकम यहाँ भरें।",
            style = MaterialTheme.typography.bodySmall)
        field("Parking (₹)", parking, { parking = it; calculated = false }, true)
        field("Night Charge (₹)", night, { night = it; calculated = false }, true)
        field("Waiting (₹)", waiting, { waiting = it; calculated = false }, true)
        field("Driver Allowance (₹)", driver, { driver = it; calculated = false }, true)
        field("अन्य खर्च (₹)", other, { other = it; calculated = false }, true)
        field("Advance मिला (₹)", advance, { advance = it; calculated = false }, true)
        Button(onClick = { calculated = true }, modifier = Modifier.fillMaxWidth()) { Text("कुल किराया निकालें") }
        if (calculated) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("कस्टमर से कुल किराया", style = MaterialTheme.typography.titleMedium)
                    Text(fmt.format(total), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("${if (roundTrip) "Round Trip" else "One Way"} • ${"%.1f".format(distance)} KM • $vehicle")
                    HorizontalDivider()
                    resultLine("KM का किराया", fmt.format(kmFare))
                    resultLine("Toll", fmt.format(n(toll)))
                    resultLine("State Tax", fmt.format(n(stateTax)))
                    resultLine("Parking", fmt.format(n(parking)))
                    resultLine("अन्य खर्च", fmt.format(extras))
                    resultLine("Advance के बाद बाकी", fmt.format(balance))
                    Button(onClick = {
                        val bill = """🚕 Amit Car Fare
Vehicle: $vehicle
$pickup → $drop
${if (roundTrip) "Round Trip" else "One Way"} | ${"%.1f".format(distance)} KM
KM Fare: ${fmt.format(kmFare)}
Toll: ${fmt.format(n(toll))}
State Tax: ${fmt.format(n(stateTax))}
Parking: ${fmt.format(n(parking))}
Night: ${fmt.format(n(night))}
Waiting: ${fmt.format(n(waiting))}
Driver: ${fmt.format(n(driver))}
Other: ${fmt.format(n(other))}
Total: ${fmt.format(total)}
Advance: ${fmt.format(n(advance))}
Balance Due: ${fmt.format(balance)}"""
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, bill) }
                        context.startActivity(Intent.createChooser(send, "बिल शेयर करें"))
                    }, modifier = Modifier.fillMaxWidth()) { Text("WhatsApp पर बिल शेयर करें") }
                }
            }
        }
        Text("ऑफलाइन: किराया कैलकुलेशन और पहले से डाउनलोड किया हुआ नक्शा चलेगा; सड़क की ऑटो दूरी के लिए इंटरनेट जरूरी है। Offline route graph और verified toll/state-tax database इस प्रोजेक्ट में शामिल नहीं हैं।",
            style = MaterialTheme.typography.bodySmall)
    }
}

private fun getDrivingDistanceKm(context: android.content.Context, pickup: String, drop: String): Pair<Double?, String?> {
    // Free OpenStreetMap Nominatim geocoding + OSRM driving router.
    // Public demo services are rate-limited and have no uptime guarantee.
    fun geocode(query: String): Pair<Double, Double>? {
        val encoded = java.net.URLEncoder.encode(query, "UTF-8")
        val url = URL("https://nominatim.openstreetmap.org/search?q=$encoded&format=jsonv2&limit=1&countrycodes=in")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 15000
            setRequestProperty("User-Agent", "AmitCarFareAndroid/1.3 (route lookup)")
            setRequestProperty("Accept", "application/json")
        }
        try {
            if (connection.responseCode !in 200..299) return null
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val arr = org.json.JSONArray(body)
            if (arr.length() == 0) return null
            val item = arr.getJSONObject(0)
            return Pair(item.getString("lon").toDouble(), item.getString("lat").toDouble())
        } finally { connection.disconnect() }
    }
    return try {
        val start = geocode(pickup) ?: return Pair(null, "Pickup नहीं मिला। शहर/राज्य सहित पूरा पता लिखें।")
        // Nominatim public service is rate-limited; pause between lookups.
        Thread.sleep(1100)
        val end = geocode(drop) ?: return Pair(null, "Drop नहीं मिला। शहर/राज्य सहित पूरा पता लिखें।")
        val routeUrl = URL("https://router.project-osrm.org/route/v1/driving/${start.first},${start.second};${end.first},${end.second}?overview=false&alternatives=false&steps=false")
        val connection = (routeUrl.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("User-Agent", "AmitCarFareAndroid/1.3 (route lookup)")
            setRequestProperty("Accept", "application/json")
        }
        try {
            if (connection.responseCode !in 200..299) return Pair(null, "रूट सेवा अभी उपलब्ध नहीं है। बाद में फिर कोशिश करें।")
            val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            val routes = json.optJSONArray("routes")
            if (json.optString("code") != "Ok" || routes == null || routes.length() == 0) {
                Pair(null, "इस Pickup और Drop के बीच सड़क का रूट नहीं मिला।")
            } else Pair(routes.getJSONObject(0).getDouble("distance") / 1000.0, null)
        } finally { connection.disconnect() }
    } catch (e: Exception) {
        Pair(null, "ऑटो सड़क दूरी के लिए इंटरनेट जरूरी है। सेवा व्यस्त हो सकती है; दोबारा कोशिश करें।")
    }
}

private fun fillCurrentLocation(context: android.content.Context, onResult: (String) -> Unit) {
    try {
        val lm = context.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        val loc: Location? = providers.mapNotNull { provider ->
            try { lm.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
        }.maxByOrNull { it.time }
        if (loc == null) {
            onResult("लोकेशन नहीं मिली। GPS चालू करके बाहर खुले स्थान पर दोबारा कोशिश करें।")
            return
        }
        val address = try {
            @Suppress("DEPRECATION")
            Geocoder(context, Locale("en", "IN")).getFromLocation(loc.latitude, loc.longitude, 1)
                ?.firstOrNull()?.getAddressLine(0)
        } catch (_: Exception) { null }
        onResult(address ?: "GPS: ${loc.latitude}, ${loc.longitude}")
    } catch (_: Exception) {
        onResult("लोकेशन प्राप्त नहीं हो सकी।")
    }
}

@Composable
fun resultLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label); Text(value, fontWeight = FontWeight.SemiBold)
    }
}
