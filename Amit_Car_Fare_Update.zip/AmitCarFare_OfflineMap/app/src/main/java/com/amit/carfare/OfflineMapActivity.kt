package com.amit.carfare

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.mapsforge.core.model.LatLong
import org.mapsforge.map.android.graphics.AndroidGraphicFactory
import org.mapsforge.map.android.util.AndroidUtil
import org.mapsforge.map.android.view.MapView
import org.mapsforge.map.datastore.MapDataStore
import org.mapsforge.map.layer.renderer.TileRendererLayer
import org.mapsforge.map.reader.MapFile
import org.mapsforge.map.rendertheme.internal.MapsforgeThemes
import java.io.File
import java.io.FileOutputStream

class OfflineMapActivity : ComponentActivity() {
    private lateinit var mapView: MapView
    private lateinit var status: TextView
    private var renderer: TileRendererLayer? = null

    private val openMap = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            loadMap(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidGraphicFactory.createInstance(application)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }
        val title = TextView(this).apply {
            text = "ऑफलाइन मैप — UP • Delhi • Haryana • Rajasthan"
            textSize = 18f
        }
        val choose = Button(this).apply {
            text = "फोन से ऑफलाइन .map फाइल चुनें"
            setOnClickListener { openMap.launch(arrayOf("*/*")) }
        }
        status = TextView(this).apply {
            text = "मैप चलाने के लिए Mapsforge की .map फाइल चुनें।"
            textSize = 14f
        }
        mapView = MapView(this).apply {
            setBuiltInZoomControls(true)
            setZoomLevelMin(5.toByte())
            setZoomLevelMax(20.toByte())
        }
        root.addView(title)
        root.addView(choose)
        root.addView(status)
        root.addView(mapView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        // पहले से इम्पोर्ट किया हुआ मैप ऐप दोबारा खुलने पर अपने-आप लोड करें।
        val savedMap = savedMapFile()
        if (savedMap.isFile && savedMap.length() > 0L) {
            status.text = "फोन में सेव ऑफलाइन मैप खोला जा रहा है…"
            loadMapFile(savedMap)
        }
    }

    private fun savedMapFile(): File =
        File(File(filesDir, "offline_maps").apply { mkdirs() }, "north_india.map")

    private fun loadMap(uri: Uri) {
        val target = savedMapFile()
        val temp = File(target.parentFile, "north_india.map.part")
        try {
            status.text = "मैप फाइल फोन में सेव हो रही है…"
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "फाइल पढ़ी नहीं जा सकी" }
                FileOutputStream(temp).use { output -> input.copyTo(output) }
            }
            require(temp.isFile && temp.length() > 0L) { "मैप फाइल खाली है" }
            if (target.exists() && !target.delete()) {
                throw IllegalStateException("पुरानी मैप फाइल अपडेट नहीं हो सकी")
            }
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
            loadMapFile(target)
        } catch (e: Exception) {
            temp.delete()
            status.text = "मैप सेव/लोड नहीं हुआ: ${e.message}\nकृपया सही Mapsforge .map फाइल चुनें।"
        }
    }

    private fun loadMapFile(mapFile: File) {
        try {
            renderer?.let {
                mapView.layerManager.layers.remove(it)
                it.onDestroy()
            }
            val dataStore: MapDataStore = MapFile(mapFile)
            val cache = AndroidUtil.createTileCache(this, "amit-map-cache",
                mapView.model.displayModel.tileSize, 1f,
                mapView.model.frameBufferModel.overdrawFactor)
            val layer = TileRendererLayer(cache, dataStore,
                mapView.model.mapViewPosition, AndroidGraphicFactory.INSTANCE)
            layer.setXmlRenderTheme(MapsforgeThemes.MOTORIDER)
            renderer = layer
            mapView.layerManager.layers.add(layer)
            val start = dataStore.startPosition() ?: LatLong(28.6139, 77.2090)
            mapView.setCenter(start)
            mapView.setZoomLevel(dataStore.startZoomLevel() ?: 8.toByte())
            status.text = "ऑफलाइन मैप लोड है और फोन में सेव है। अगली बार अपने-आप खुलेगा।"
        } catch (e: Exception) {
            status.text = "मैप नहीं खुला: ${e.message}\nकृपया सही Mapsforge .map फाइल चुनें।"
        }
    }

    override fun onDestroy() {
        if (::mapView.isInitialized) mapView.destroyAll()
        AndroidGraphicFactory.clearResourceMemoryCache()
        super.onDestroy()
    }
}
