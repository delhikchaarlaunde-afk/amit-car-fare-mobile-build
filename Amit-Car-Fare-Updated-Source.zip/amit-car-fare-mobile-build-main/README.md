# Amit Car Fare – updated source

The GitHub Actions workflow at `.github/workflows/build-apk.yml` builds the latest `Amit_Car_Fare_Update.zip` archive (not the older OTP_LOGIN archive).

## Firebase setup
1. Open Firebase Console → Firestore Database → Rules.
2. Copy the contents of `AmitCarFare_OfflineMap/firestore.rules` and publish the rules.
3. Ensure Firebase Authentication → Sign-in method → Anonymous is enabled.
4. Push this repository to the `main` branch, or run Actions → Build Amit Car Fare APK → Run workflow.
5. Download the `Amit-Car-Fare-APK` artifact from the completed workflow.

## Important security note
This source currently uses Firebase Anonymous Authentication and a phone/PIN check inside the Android app. Firestore Rules cannot securely identify the Admin from that client-side phone/PIN. The included rules are for controlled testing only: any signed-in anonymous user can create a booking. Before public launch, replace this with verified Phone Authentication plus a trusted backend/custom Admin claim. Do not treat the local PIN as production security.

## Booking behavior
Drivers see open bookings while the app is running. A Firestore transaction makes the first successful driver acceptance win; the booking then disappears from other drivers' open list and remains assigned to that driver's orders. The app plays a short in-app alert for new bookings while the booking screen is open. Background/closed-app push notifications require Firebase Cloud Messaging and a trusted sender/backend; they are not included in this source.

## Offline map
Choose a Mapsforge `.map` file, then press **मैप सेव करें**. The app stores it in its private app storage and automatically loads it the next time it opens.
